import socket
import sys
import time
import threading

server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)

if len(sys.argv)!=3:
	print("script_name IP_address port_no")
	exit()

host_name=str(sys.argv[1])
port=int(sys.argv[2])


#binding
server.bind((host_name,port))
print("hostname and port bound together")
print("server is now listening")

server.listen(10)#we will only accept 10 connections
client_list=[]

def clientJoins(client_socket,ip):
	welcome="Welcome to this chatroom"
	welcome=welcome.encode()
	client_socket.send(welcome)
	while(1):
		try:
			msg=client_socket.recv(2048)
			if msg:
				msg=msg.decode()
				response="<"+ip[0]+">: "+msg
				print(response)
				broadcast(response)
			else:
				remove(client_socket)
		except:
			continue

def broadcast(msg,client_socket):
	for client in client_list:
		if client!=client_socket:
			try:
				client.send(msg)
			except:
				client.close()
				remove(client)


def remove(client_socket):
	if client_socket in client_list:
		client_socket.remove(client_socket)

i=1
while(1):
	client_socket,ip=server.accept()#connection is socket of client and ip is IP address of client
	client_list.append(client_socket)
	print(ip[0]," is connected")

	threading.Thread(target=clientJoins,args=(client_socket,ip)).start()

client_socket.close()
server.close()

				



# print(ip,"is now connected and ONLINE")
# while(1):
# 	response=input(str(">>"))
# 	response=response.encode()
# 	client_socket.send(response)
# 	print("response sent")
# 	request=client_socket.recv(1024)
# 	request=request.decode()
# 	print("Client: ",request)